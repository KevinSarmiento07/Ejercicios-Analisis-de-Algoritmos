/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trainincCenter2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

/**
 *
 * @author kevin
 */
public class Glosario {

    public static void main(String[] args) {

        Scanner s = new Scanner(System.in);

        int nCasos = s.nextInt();
        
        while (nCasos > 0) {
            ArrayList<String> arr = new ArrayList<>();
            int palabras = s.nextInt();
            s.nextLine();
            while (s.hasNext()) {
                String lineaCompleta = s.nextLine().replaceAll("[^a-zA-Z0-9\\s]", "");
                String linea[] = lineaCompleta.split(" ");
                if (linea[0].equals("FIN")) {
                    break;
                }
                for (int i = 0; i < linea.length; i++) {
                    
                    
                    
                    
                    if (!arr.contains(linea[i])) {
                        arr.add(linea[i]);
                    }

                }

            }

            
            Collections.sort(arr);
            arr.add("-");
            for (int i = 0; i < arr.size(); i++) {
                System.out.println(arr.get(i));
            }

            nCasos--;
        }

    }
}
