/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trainincCenter2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class PalabraMasComun {

    public static void main(String[] args) {

        Scanner s = new Scanner(System.in);
        int nCasos = s.nextInt();
        s.nextLine();

        while (nCasos > 0) {
            ArrayList<String> arr = new ArrayList<>();

            String linea[] = s.nextLine().split(" ");

            int palabras = Integer.parseInt(linea[0]);
            for (int i = 1; i <= palabras; i++) {
                arr.add(linea[i]);
            }
            System.out.println(palabraMasRepetida(arr));

            nCasos--;
        }
    }

    public static String palabraMasRepetida(ArrayList<String> list) {
        ArrayList<String> arr = new ArrayList<>();
        Map<String, Integer> map = new HashMap<String, Integer>();
        String palabraMasRepetida = "";
        int maxRepeticiones = 0;
        
        for (String palabra : list) {
            if (map.containsKey(palabra)) {
                int repeticiones = map.get(palabra) + 1;
                map.put(palabra, repeticiones);
                if (repeticiones > maxRepeticiones) {
                    maxRepeticiones = repeticiones;
                    palabraMasRepetida = palabra;
                }
            } else {
                map.put(palabra, 1);
            }
        }
        
        if(maxRepeticiones == 0){
            maxRepeticiones = 1;
        }

        int contador = 0;
        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            if (entry.getValue().equals(maxRepeticiones)) {
                contador++;
            }
        }
        if (contador == 1) {
            return palabraMasRepetida;
        } else {
            for (Map.Entry<String, Integer> entry : map.entrySet()) {
                int maxRep = maxRepeticiones;
                if (entry.getValue() == maxRep) {
                    arr.add(entry.getKey());
                }
            }
            Collections.sort(arr);
            return arr.get(0);
        }
    }
}
