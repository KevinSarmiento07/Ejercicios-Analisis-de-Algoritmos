/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trainincCenter2;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author kevin
 */
public class Simetria {

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int nCasos = s.nextInt();                       // O(1)
        while (nCasos-- > 0) {                           // O(nCasos)
            int nFilas = s.nextInt();                    // O(1)
            int nColumnas = nFilas;                       // O(1)
            char[][] matriz = new char[nFilas][nColumnas];// O(nFilas * nColumnas)
            s.nextLine();                                // O(1)
            for (int i = 0; i < nFilas; i++) {            // O(nFilas)
                String linea = s.nextLine();             // O(1)
                for (int j = 0; j < nColumnas; j++) {     // O(nColumnas)
                    matriz[i][j] = (linea.charAt(j));     // O(1)
                }
            }
            boolean esSimetrica = true;                  // O(1)
            for (int i = 0; i < nFilas && esSimetrica; i++) {// O(nFilas)
                for (int j = 0; j < nColumnas && esSimetrica; j++) {// O(nColumnas)
                    if (matriz[i][j] != matriz[nFilas - i - 1][nColumnas - j - 1]) {// O(1)
                        esSimetrica = false;             // O(1)
                    }
                }
            }
            if (esSimetrica) {                           // O(1)
                System.out.println("YES");              // O(1)
            } else {
                System.out.println("NO");               // O(1)
            }
        }
    }
}
/*
        Scanner s = new Scanner(System.in);
        ArrayList<String> arr = new ArrayList<>();
        int nCasos = s.nextInt();
        while(nCasos-- >0){
            int tamanio = s.nextInt();
            s.nextLine();
            char matriz[][] = new char [tamanio][tamanio]; 
            for(int i = 0; i < tamanio;  i++){
                String linea = s.nextLine();
                for(int j = 0; j < tamanio; j++){
                    matriz[i][j] = (linea.charAt(j));
                }
            }
            boolean diferencia = false;
            int ultimoI = tamanio-1;
            for(int i = 0; i < tamanio;  i++){
                int ultimoJ = tamanio-1;
                for(int j = 0; j < tamanio; j++){
                    if(matriz[i][j] != matriz[ultimoI][ultimoJ]){
                        diferencia = true;
                        break;
                    }
                    ultimoJ--;
                }
                if(diferencia){
                    break;
                }
                ultimoI--;
            }
            if(diferencia == true){
                arr.add("NO");
            }else{
                arr.add("YES");
            }
        }
        
        for(int i = 0; i < arr.size(); i++){
            if(i == arr.size()-1){
                System.out.print(arr.get(i));
            }else{
                System.out.println(arr.get(i));
            }
            
        }
 */
